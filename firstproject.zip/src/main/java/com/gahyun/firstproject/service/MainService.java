package com.gahyun.firstproject.service;


public interface MainService {

    public String hello();
    
}
